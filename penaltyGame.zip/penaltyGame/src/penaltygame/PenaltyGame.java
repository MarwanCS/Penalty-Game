package penaltygame;
import java.util.Timer;
import java.util.TimerTask;
public class PenaltyGame extends javax.swing.JFrame {
int sfrkrdn=0;
        boolean brom=true;
        boolean time=true;
        int y=-1;
        int z=-1;
        int shootZhmer=0;
        int goal=0;
   public void jwlla(int shoot,int  randomPlaceGallKepper)
   {
       
       y=shoot;
       z=randomPlaceGallKepper;
       if(z==y)
       {
           shootZhmer++;
           shootCount.setText("SHOOT :"+shootZhmer);
       }
       else
       {
         shootZhmer++;
         goal++;
           shootCount.setText("SHOOT :"+shootZhmer);   
            scoreCount.setText("SCORE :"+goal);   
       }
       brom=true;
       right.setVisible(false);
       center.setVisible(false);
       left.setVisible(false);
       Timer myTimer=new Timer();
      TimerTask task=new TimerTask()
       {
           @Override
           public void run() {
               if(brom==true)
               {
                 if(z==1&&gallKepper.getLocation().x>370)
             gallKepper.setLocation(gallKepper.getLocation().x-1,gallKepper.getLocation().y);
           if(z==2&&gallKepper.getLocation().x<850)
            gallKepper.setLocation(gallKepper.getLocation().x+1,gallKepper.getLocation().y);
            if(z==0)
             gallKepper.setLocation(gallKepper.getLocation().x,gallKepper.getLocation().y);
               if(y==1  &&ball.getLocation().x>390 &&ball.getLocation().y>170)
             ball.setLocation(ball.getLocation().x-1,ball.getLocation().y-1 );
           if(y==2&&ball.getLocation().x<870 &&ball.getLocation().y>170)
             ball.setLocation(ball.getLocation().x+1,ball.getLocation().y-1);
            if(y==0&&ball.getLocation().y>320)
             ball.setLocation(ball.getLocation().x,ball.getLocation().y-1);
            sfrkrdn++;
               }
            if(sfrkrdn==450)
            {
                
                brom=false;
                sfrkrdn=0;
                sarata();
                right.setVisible(true);
       center.setVisible(true);
       left.setVisible(true);
            }
           }
           
       };
    
      if(time==true)
      {
      myTimer.schedule(task, 1,1);
      time=false;
      }
   }
   public void sarata()
   {      
        gallKepper.setLocation(610,250);
        ball.setLocation(640,560);
   }
    public PenaltyGame() {
        initComponents();
        setSize(1365, 730);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        scoreCount = new javax.swing.JLabel();
        shootCount = new javax.swing.JLabel();
        right = new javax.swing.JLabel();
        center = new javax.swing.JLabel();
        left = new javax.swing.JLabel();
        ball = new javax.swing.JLabel();
        gallKepper = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Penalty Kick");
        getContentPane().setLayout(null);

        jPanel1.setLayout(null);

        scoreCount.setBackground(new java.awt.Color(255, 255, 255));
        scoreCount.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        scoreCount.setForeground(new java.awt.Color(255, 255, 255));
        scoreCount.setText("SCORE : 0");
        jPanel1.add(scoreCount);
        scoreCount.setBounds(120, 0, 110, 40);

        shootCount.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        shootCount.setForeground(new java.awt.Color(255, 255, 255));
        shootCount.setText("SHOOT : 0");
        jPanel1.add(shootCount);
        shootCount.setBounds(4, 5, 110, 30);

        right.setToolTipText("RIGHT");
        right.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        right.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rightMouseClicked(evt);
            }
        });
        jPanel1.add(right);
        right.setBounds(390, 240, 210, 170);

        center.setToolTipText("CENTER");
        center.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        center.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                centerMouseClicked(evt);
            }
        });
        jPanel1.add(center);
        center.setBounds(604, 245, 160, 170);

        left.setToolTipText("LEFT");
        left.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        left.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                leftMouseClicked(evt);
            }
        });
        jPanel1.add(left);
        left.setBounds(764, 245, 210, 170);

        ball.setIcon(new javax.swing.ImageIcon(getClass().getResource("/penaltygame/balll.png"))); // NOI18N
        ball.setText("jLabel2");
        jPanel1.add(ball);
        ball.setBounds(640, 560, 80, 80);

        gallKepper.setIcon(new javax.swing.ImageIcon(getClass().getResource("/penaltygame/goalKeeperrr.png"))); // NOI18N
        jPanel1.add(gallKepper);
        gallKepper.setBounds(610, 250, 160, 170);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/penaltygame/stadium.jpg"))); // NOI18N
        jPanel1.add(jLabel1);
        jLabel1.setBounds(0, 0, 1370, 730);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 0, 1370, 730);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void rightMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rightMouseClicked
     int randomPlaceGallKepper=(int)(Math.random()*3);
        jwlla(1,randomPlaceGallKepper);
        
    }//GEN-LAST:event_rightMouseClicked

    private void centerMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_centerMouseClicked
        int randomPlaceGallKepper=(int)(Math.random()*3);
        jwlla(0,randomPlaceGallKepper);
    }//GEN-LAST:event_centerMouseClicked

    private void leftMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_leftMouseClicked
      int randomPlaceGallKepper=(int)(Math.random()*3);
        jwlla(2,randomPlaceGallKepper);
    }//GEN-LAST:event_leftMouseClicked

  
    public static void main(String args[]) {

        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PenaltyGame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PenaltyGame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PenaltyGame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PenaltyGame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PenaltyGame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel ball;
    private javax.swing.JLabel center;
    private javax.swing.JLabel gallKepper;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel left;
    private javax.swing.JLabel right;
    private javax.swing.JLabel scoreCount;
    private javax.swing.JLabel shootCount;
    // End of variables declaration//GEN-END:variables
}
